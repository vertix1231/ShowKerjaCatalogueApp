# ShowCatalogueApp2
JETPACK ANDROID DICODINF BANGKIT 2021 SUBMISI 2

Submission 2 Repository dan LiveData
Kriteria
Fitur yang harus ada pada aplikasi :

Daftar film
Syarat :

Mempertahankan fitur sebelumnya.
Menerapkan ViewModel,LiveData dan Repository.
Detail film
Syarat :

Mempertahankan fitur sebelumnya.
Menerapkan ViewModel, LiveData dan Repository.
Unit Test
Syarat :

Menerapkan unit test pada semua fungsi yang digunakan untuk mendapatkan data Movie dan Tv Show dari API atau Lokal.
Instrumentation Tests
Syarat:

Menerapkan instrumentation test untuk memastikan fitur-fitur yang ada berjalan dengan semestinya.
Jika pada aplikasi terdapat proses asynchronous, maka Anda wajib menerapkan Idle Resources.
